var player, back;
var points = 0;
var backImg;
var leftPlayerImg;
var rightPlayerImg;
var gameState= "START";
var baseImg, baseGroup;
var goodImg, goodThingsGroup;
var badImg, badThingsGroup;

//Función para cargar imágenes y animaciones
function preload() {
leftPlayerImg = loadAnimation ("Imagenes/willyLeft.png");
baseImg = loadImage("Imagenes/base.png");
backImg =loadImage("Imagenes/Clouds Back.png");
goodImg= loadImage("Imagenes/goodthing.png");  
}
//Función para declarar Sprites y grupos
function setup() { 
  createCanvas(450,800);
  back = createSprite(225,400,20,20);
  back.addImage(backImg)
  back.scale=0.5
  player=createSprite(225,450,20,20);
  player.addAnimation("left",leftPlayerImg);
  player.scale= 0.05
  baseGroup = new Group();
  goodThingsGroup = new Group()
  
}
//Función para dibujar los Sprites y establecer reglas del juego
function draw() {
  background(220);
  drawSprites();
  
  
  //Puntuación 
  fill("orange")
 textSize(19)
 text("Points" + points,50,100)
  //Inicio del juego
  if(gameState==="START" && keyDown("up_arrow") ){
  //Velocidad y cambio de estado 
    gameState="PLAY"
     }
  
    if(gameState==="PLAY"){
    //Fondo infinito
   back.velocityY = 1
   if(back.y>425){
   back.y=300  
   }   
    //gravedad
    player.velocityY=player.velocityY +0.8;
      
    //Mover personaje con las flechas
      
if(keyDown("right_arrow")){
player.x=player.x+3;
   
}
if(keyDown("left_arrow")) {
player.x=player.x-3;
    
}     
if(keyDown("up_arrow")){
player.velocityY = -4;
}
      
    //crear bases y hacer que el personaje quede sobre ellas
      
      createBases();
if(player.isTouching(baseGroup)){
player.velocityY = 0; 
}
      
    //Aumentar puntos
      
if(player.isTouching(goodThingsGroup,removeGoodThings)){
 points= points+10  
}    
    //crear Cosas Malas 
      
    //Cambiar a estado GAMEOVER
    
  }
  
  //Estado GAMEOVER 
  
  if(gameState==="GAMEOVER"){
     }
  
}

//Función para crear bases 
function createBases(){
   if(frameCount % 100 === 0){
     var base=createSprite(random(50,450),0,70,20);
     base.velocityY=2;
     base.addImage(baseImg);
     base.scale = 0.30
     baseGroup.add(base);
     var good = createSprite(base.x,base.y-15,20,20);
     good.velocityY = 2;
     good.addImage(goodImg);
     good.scale = 0.12
     goodThingsGroup.add(good);
   }
}

//Función para crear Cosas Malas 

function createBadThings(){
  var velo = 3;
  if(frameCount % 75 === 0){
     
}
}

//Función para eliminar CosasBuenas
function removeGoodThings(sprite,goodThingsGroup ){
 goodThingsGroup.remove();
}

